# roboMind > 2025-10-17 3:33pm
https://universe.roboflow.com/korsh624/robomind-imiy0

Provided by a Roboflow user
License: CC BY 4.0

